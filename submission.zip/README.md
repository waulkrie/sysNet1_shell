To compile the program run 'make'
To clean compilation objects run 'make clean'
Redirects are expected to be ONE token '>output.txt' NOT '> output.txt'
